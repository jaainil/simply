const { series, watch, src, dest, parallel } = require("gulp");
const pump = require("pump");

const rename = require("gulp-rename");
const replace = require("gulp-replace");

// gulp plugins and utils
const livereload = require("gulp-livereload");
const beeper = require("beeper");
const postcss = require("gulp-postcss");
const gulpif = require("gulp-if");
const sourcemaps = require("gulp-sourcemaps");
const header = require("gulp-header");

// Babel
const browserify = require("browserify");
const source = require("vinyl-source-stream");
const buffer = require("vinyl-buffer");
const uglify = require("gulp-uglify");
//
const merge = require("merge-stream");

// postcss plugins
const cssnano = require("cssnano");
const comments = require("postcss-discard-comments");
const simpleExtend = require("postcss-extend");
const tailwindcss = require("@tailwindcss/postcss");
// const lol = require('postcss-advanced-variables')
const postImport = require("postcss-import");
const precss = require("precss");

// sass
// const sass = require('gulp-sass')(require('sass'))

// environment
const isProduction =
  process.argv.includes("--production") ||
  process.env.NODE_ENV === "production";

// Data collection on the theme
const {
  name,
  version,
  author,
  license,
  repository,
} = require("./package.json");

// Build Comments
const BuildComments = `/*!
 * ${name} v${version}
 * Copyright ${new Date().getFullYear()} ${author.name} <${author.email}> (${
  repository.url
})
 * Licensed under ${license}
 */`;

// clean assets
const clean = async () => {
  const { deleteAsync } = await import("del");
  return deleteAsync(["assets", "partials/styles", "dis"], { force: true });
};

function serve(done) {
  livereload.listen();
  done();
}

const handleError = (done) => {
  return function (err) {
    if (err) {
      beeper();
    }
    return done(err);
  };
};

// hbs
// function hbs (done) {
//   pump([
//     src(['*.hbs', 'partials/**/*.hbs']),
//     livereload()
//   ], handleError(done))
// }

const postcssPluginsDev = [
  postImport({
    onImport() {},
    warnWhenNotFound: false
  }),
  simpleExtend(),
  precss(),
  (root, result) => {
    const messages = result.messages.filter(m => 
      !m.text || !m.text.includes('@import must precede')
    );
    result.messages.length = 0;
    messages.forEach(m => result.messages.push(m));
  },
  tailwindcss(),
];

const postcssPluginsPro = [
  cssnano(),
  comments({ removeAll: true }),
];

// style
function styles(done) {
  pump(
    [
      src("src/css/*.css"),
      gulpif(!isProduction, sourcemaps.init()),
      // sass({ outputStyle: 'expanded' }).on('error', sass.logError),
      gulpif(!isProduction, postcss(postcssPluginsDev)),
      gulpif(
        isProduction,
        postcss(postcssPluginsDev.concat(postcssPluginsPro))
      ),
      gulpif(isProduction, header(BuildComments)),
      gulpif(!isProduction, sourcemaps.write("./map")),
      dest("assets/styles"),
      livereload(),
    ],
    handleError(done)
  );
}

// Scripts
function scripts(done) {
  const files = ["main", "post", "prismjs", "kusi-doc-post", "pagination"];

  merge(
    files.map(function (file) {
      return pump(
        [
          browserify({
            basedir: ".",
            debug: true,
            entries: `./src/js/${file}.js`,
            cache: {},
            packageCache: {},
          })
            .transform("babelify", {
              presets: ["@babel/env"],
              plugins: ["@babel/plugin-transform-runtime"],
            })
            .bundle(),
          source(`${file}.js`),
          buffer(),
          gulpif(!isProduction, sourcemaps.init()),
          gulpif(isProduction, uglify()),
          gulpif(isProduction, header(BuildComments)),
          gulpif(!isProduction, sourcemaps.write("./map")),
          dest("assets/scripts"),
          livereload(),
        ],
        handleError(done)
      );
    })
  );
}

// Image
async function images(done) {
  const imagemin = (await import("gulp-imagemin")).default;
  const imageminGifsicle = (await import("imagemin-gifsicle")).default;
  const imageminMozjpeg = (await import("imagemin-mozjpeg")).default;
  const imageminOptipng = (await import("imagemin-optipng")).default;
  const imageminSvgo = (await import("imagemin-svgo")).default;

  pump(
    [
      src("src/img/**/*.*"),
      imagemin([
        imageminGifsicle(),
        imageminMozjpeg(),
        imageminOptipng(),
        imageminSvgo(),
      ]),
      dest("assets/images"),
      livereload(),
    ],
    handleError(done)
  );
}



function copyMainStyle(done) {
  pump(
    [
      src("assets/styles/main.css"),
      replace('@charset "UTF-8";', ""),
      postcss([cssnano(), comments({ removeAll: true })]),
      rename("main-styles.hbs"),
      dest("partials"),
    ],
    handleError(done)
  );
}

// ZIP
async function zipper(done) {
  const filename = `${name}-v${version}.zip`;
  const zip = (await import("gulp-zip")).default;

  pump(
    [
      src(
        [
          "assets/**",
          "locales/*.json",
          "*.hbs",
          "partials/**",
          "podcast/**",
          "LICENSE",
          "package.json",
          "README.md",
          "!node_modules",
          "!node_modules/**",
          "!dist",
          "!dist/**",
          "!src",
          "!src/**",
        ],
        { base: "." }
      ),
      zip(filename),
      dest("dist"),
    ],
    handleError(done)
  );
}

// TryGhost Admin
const dotenv = require("dotenv");
const path = require("path");
const GhostAdminApi = require("@tryghost/admin-api");

const ENV_FILE = path.join(__dirname, ".env");
const env = dotenv.config({ path: ENV_FILE });

async function deploy(done) {
  try {
    const url = process.env.GHOST_API_URL || env.parsed.GHOST_API_URL;
    console.log(url);
    const adminApiKey =
      process.env.GHOST_ADMIN_API_KEY || env.parsed.GHOST_ADMIN_API_KEY;
    console.log(adminApiKey);
    const themeName = process.env.THEME_NAME || require("./package.json").name;
    console.log("name =", themeName);
    const apiVersion =
      process.env.API_VERSION || require("./package.json").engines["ghost-api"];
    console.log(apiVersion);
    const zipFile = `./dist/${themeName}-v${version}.zip`;
    console.log("zip = ", zipFile);

    const api = new GhostAdminApi({
      url,
      key: adminApiKey,
      version: apiVersion,
    });

    await api.themes
      .upload({ file: zipFile })
      .then((response) => console.log(response))
      .catch((error) => console.error(error));
    console.log("uploaded");
    await api.themes
      .activate(`${themeName}-v${version}`)
      .then((response) => console.log(response))
      .catch((error) => console.error(error));
    console.log("activated");
    done();
  } catch (err) {
    console.log("error caught");
    handleError(done);
  }
}

const cssWatcher = () => watch("src/css/**", styles);
const jsWatcher = () => watch(["src/js/**", "*.js"], scripts);
const imgWatcher = () => watch("src/img/**", images);
// const hbsWatcher = () => watch(['*.hbs', 'partials/**/*.hbs'], hbs)
const hbsWatcher = () => watch(["*.hbs", "partials/**/*.hbs"], styles);

const compile = parallel(styles, scripts, images);
const watcher = parallel(cssWatcher, jsWatcher, imgWatcher, hbsWatcher);

const build = series(clean, compile);
const production = series(build, copyMainStyle, zipper);
// const production = series(build)
const development = series(build, serve, watcher);

module.exports = { build, development, production, deploy };
